//
//  loginModel.m
//  凤凰新闻App
//
//  Created by lanou on 16/3/24.
//  Copyright © 2016年 jianjun. All rights reserved.
//

#import "loginModel.h"

@implementation loginModel

@end
