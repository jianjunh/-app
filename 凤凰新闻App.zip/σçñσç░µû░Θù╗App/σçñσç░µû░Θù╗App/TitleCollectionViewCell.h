//
//  TitleCollectionViewCell.h
//  凤凰新闻App
//
//  Created by lanou on 16/3/16.
//  Copyright © 2016年 jianjun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong)UILabel *titleLabel;

@end
