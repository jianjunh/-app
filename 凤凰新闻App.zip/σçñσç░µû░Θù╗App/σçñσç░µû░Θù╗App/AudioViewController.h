//
//  AudioViewController.h
//  凤凰新闻App
//
//  Created by lanou on 16/3/15.
//  Copyright © 2016年 jianjun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AudioViewController : UIViewController

@property (nonatomic,strong)UIView *headerView;

@end
